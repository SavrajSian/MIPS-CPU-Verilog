#!/bin/bash
set -eou pipefail

srcdir="$1"

TESTCASES="test/testcases/*.v"

for i in ${TESTCASES} ; do
	TESTNAME=$(basename ${i} .v)
	iverilog -Wall -g 2012 -I"test/testcases/" -s ${TESTNAME}_tb\
 	-o ${TESTNAME}_tb "test/testcases/"${TESTNAME}.v ${srcdir}/mips_cpu_*.v ${srcdir}/mips_cpu/*.v "test/"*RAM*.v

	set +e
	./${TESTNAME}_tb>/dev/null
	RESULT=$?
	set -e

	if [[ "${RESULT}" -eq 0 ]] ; then
   	echo "${TESTNAME}, ${TESTNAME//[^[:alpha:]]/}, Pass"
	else
   	echo "${TESTNAME}, ${TESTNAME//[^[:alpha:]]/}, Instruction Failed"
	fi
done






